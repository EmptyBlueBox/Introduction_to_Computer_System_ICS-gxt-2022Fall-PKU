/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_473()
{
    return 2425376975U;
}

unsigned addval_292(unsigned x)
{
    return x + 3284633928U;
}

void setval_474(unsigned *p)
{
    *p = 3347662900U;
}

unsigned getval_136()
{
    return 3284633864U;
}

void setval_123(unsigned *p)
{
    *p = 3260561656U;
}

unsigned addval_351(unsigned x)
{
    return x + 1489192232U;
}

void setval_286(unsigned *p)
{
    *p = 2425393240U;
}

unsigned addval_410(unsigned x)
{
    return x + 3347663983U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

void setval_120(unsigned *p)
{
    *p = 3281049225U;
}

unsigned getval_425()
{
    return 2429192684U;
}

unsigned addval_154(unsigned x)
{
    return x + 3683961481U;
}

unsigned getval_322()
{
    return 2497087907U;
}

void setval_337(unsigned *p)
{
    *p = 3353381192U;
}

void setval_167(unsigned *p)
{
    *p = 3677932169U;
}

unsigned addval_356(unsigned x)
{
    return x + 3375939981U;
}

void setval_101(unsigned *p)
{
    *p = 3687104905U;
}

unsigned addval_498(unsigned x)
{
    return x + 3223372169U;
}

unsigned getval_415()
{
    return 3252062511U;
}

void setval_173(unsigned *p)
{
    *p = 2429946211U;
}

void setval_279(unsigned *p)
{
    *p = 3252717896U;
}

unsigned getval_207()
{
    return 3682915977U;
}

void setval_282(unsigned *p)
{
    *p = 2445969721U;
}

unsigned addval_208(unsigned x)
{
    return x + 3286272320U;
}

unsigned getval_250()
{
    return 2497743176U;
}

void setval_323(unsigned *p)
{
    *p = 3703687817U;
}

unsigned getval_316()
{
    return 3286273352U;
}

unsigned addval_289(unsigned x)
{
    return x + 3281043849U;
}

unsigned getval_342()
{
    return 3523791489U;
}

unsigned addval_295(unsigned x)
{
    return x + 3532966537U;
}

unsigned getval_240()
{
    return 3381974665U;
}

unsigned addval_396(unsigned x)
{
    return x + 3221275017U;
}

unsigned getval_153()
{
    return 3286272328U;
}

void setval_463(unsigned *p)
{
    *p = 3674789545U;
}

void setval_152(unsigned *p)
{
    *p = 3677932173U;
}

unsigned getval_298()
{
    return 3286272328U;
}

unsigned addval_124(unsigned x)
{
    return x + 3348152713U;
}

void setval_370(unsigned *p)
{
    *p = 3675832713U;
}

unsigned getval_435()
{
    return 3531129225U;
}

void setval_394(unsigned *p)
{
    *p = 3281311369U;
}

unsigned addval_392(unsigned x)
{
    return x + 3286272330U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
